-- ============================================
-- SIMMONS FINANCIAL DASHBOARD — DATABASE SETUP
-- Run this entire file in Supabase SQL Editor
-- ============================================

-- STATEMENTS table
CREATE TABLE IF NOT EXISTS statements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  period_start DATE,
  period_end DATE,
  statement_date DATE,
  beginning_balance DECIMAL(12,2),
  ending_balance DECIMAL(12,2),
  total_credits DECIMAL(12,2),
  total_debits DECIMAL(12,2),
  transaction_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TRANSACTIONS table
CREATE TABLE IF NOT EXISTS transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  statement_id UUID REFERENCES statements(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  description TEXT,
  amount DECIMAL(12,2) NOT NULL,
  type TEXT CHECK (type IN ('debit', 'credit')),
  category TEXT DEFAULT 'other',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- LIVE EXPENSES table (persists the tracker tab)
CREATE TABLE IF NOT EXISTS live_expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  amount DECIMAL(12,2) NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES for fast queries
CREATE INDEX IF NOT EXISTS idx_statements_user ON statements(user_id);
CREATE INDEX IF NOT EXISTS idx_statements_date ON statements(statement_date);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category);
CREATE INDEX IF NOT EXISTS idx_live_expenses_user ON live_expenses(user_id);

-- ROW LEVEL SECURITY (users can only see their own data)
ALTER TABLE statements ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE live_expenses ENABLE ROW LEVEL SECURITY;

-- RLS POLICIES
CREATE POLICY "Users see own statements" ON statements FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users see own transactions" ON transactions FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users see own expenses" ON live_expenses FOR ALL USING (auth.uid() = user_id);

-- STORAGE BUCKET for PDFs
-- NOTE: Run this separately in Supabase Storage UI
-- Create a bucket called "statements" and set it to private
