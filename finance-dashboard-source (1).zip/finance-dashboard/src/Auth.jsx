import { useState } from 'react'
import { supabase } from './supabase'

const C = {
  bg: '#080812', surface: '#10101e', surface2: '#16162a',
  border: '#1e1e35', muted: '#6b6b8a', green: '#00d4aa',
  red: '#ff5757', text: '#f0ebe3', blue: '#4a9eff'
}

export default function Auth({ onLogin }) {
  const [mode, setMode] = useState('login') // login | signup | forgot
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState(null)
  const [error, setError] = useState(null)

  const inputStyle = {
    width: '100%', background: C.surface2, border: `1px solid ${C.border}`,
    borderRadius: 10, color: C.text, padding: '12px 14px', fontSize: 14,
    outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit',
    transition: 'border-color 0.15s'
  }

  const handleSubmit = async () => {
    setError(null)
    setMessage(null)
    setLoading(true)

    try {
      if (mode === 'login') {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        onLogin(data.user)

      } else if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        setMessage('✅ Account created! Check your email to confirm, then log in.')
        setMode('login')

      } else if (mode === 'forgot') {
        const { error } = await supabase.auth.resetPasswordForEmail(email)
        if (error) throw error
        setMessage('✅ Password reset email sent!')
      }
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  return (
    <div style={{
      minHeight: '100vh', background: C.bg, display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: 24
    }}>
      <div style={{
        background: C.surface, border: `1px solid ${C.border}`,
        borderRadius: 20, padding: 40, width: '100%', maxWidth: 420
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>💰</div>
          <div style={{ fontFamily: 'Georgia, serif', fontSize: 24, fontWeight: 700 }}>
            Simmons Financial
          </div>
          <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>
            {mode === 'login' ? 'Sign in to your dashboard' :
             mode === 'signup' ? 'Create your account' :
             'Reset your password'}
          </div>
        </div>

        {/* Error / Message */}
        {error && (
          <div style={{ background: 'rgba(255,87,87,0.1)', border: '1px solid rgba(255,87,87,0.3)', borderRadius: 10, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: C.red }}>
            {error}
          </div>
        )}
        {message && (
          <div style={{ background: 'rgba(0,212,170,0.1)', border: '1px solid rgba(0,212,170,0.3)', borderRadius: 10, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: C.green }}>
            {message}
          </div>
        )}

        {/* Form */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, letterSpacing: 1 }}>EMAIL</div>
          <input type="email" placeholder="you@email.com" value={email}
            onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            style={inputStyle}
            onFocus={e => e.target.style.borderColor = C.green}
            onBlur={e => e.target.style.borderColor = C.border} />
        </div>

        {mode !== 'forgot' && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, letterSpacing: 1 }}>PASSWORD</div>
            <input type="password" placeholder="••••••••" value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              style={inputStyle}
              onFocus={e => e.target.style.borderColor = C.green}
              onBlur={e => e.target.style.borderColor = C.border} />
          </div>
        )}

        <button onClick={handleSubmit} disabled={loading}
          style={{
            width: '100%', background: loading ? C.surface2 : 'linear-gradient(135deg, #00d4aa, #4a9eff)',
            border: 'none', borderRadius: 12, color: loading ? C.muted : '#000',
            padding: '13px', fontSize: 14, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
            marginBottom: 16
          }}>
          {loading ? '...' :
           mode === 'login' ? '→ Sign In' :
           mode === 'signup' ? '→ Create Account' : '→ Send Reset Email'}
        </button>

        {/* Mode switchers */}
        <div style={{ textAlign: 'center', fontSize: 13, color: C.muted }}>
          {mode === 'login' && (
            <>
              <span style={{ color: C.green, cursor: 'pointer' }} onClick={() => { setMode('forgot'); setError(null); }}>Forgot password?</span>
              <span style={{ margin: '0 10px' }}>·</span>
              <span style={{ color: C.green, cursor: 'pointer' }} onClick={() => { setMode('signup'); setError(null); }}>Create account</span>
            </>
          )}
          {(mode === 'signup' || mode === 'forgot') && (
            <span style={{ color: C.green, cursor: 'pointer' }} onClick={() => { setMode('login'); setError(null); }}>← Back to sign in</span>
          )}
        </div>

        <div style={{ marginTop: 24, padding: '12px 14px', background: C.surface2, borderRadius: 10, fontSize: 12, color: C.muted, textAlign: 'center' }}>
          🔒 Access is restricted to authorized users only
        </div>
      </div>
    </div>
  )
}
