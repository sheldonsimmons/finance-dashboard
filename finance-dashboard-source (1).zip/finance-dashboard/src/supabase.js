import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://orjtevsavxglitxgbxku.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9yanRldnNhdnhnbGl0eGdieGt1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgwODU3NjQsImV4cCI6MjA5MzY2MTc2NH0.0-Tjgls2SaPjn80G3070Q0Elu4_fsMGfoFLZ40k8eWs'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
