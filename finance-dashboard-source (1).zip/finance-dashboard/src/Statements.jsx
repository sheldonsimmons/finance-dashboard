import { useState, useEffect } from 'react'
import { supabase } from './supabase'

const C = {
  bg: '#080812', surface: '#10101e', surface2: '#16162a',
  border: '#1e1e35', muted: '#6b6b8a', green: '#00d4aa',
  red: '#ff5757', orange: '#ff8c42', text: '#f0ebe3', yellow: '#ffd166', blue: '#4a9eff'
}

export default function Statements({ user }) {
  const [statements, setStatements] = useState([])
  const [uploading, setUploading] = useState(false)
  const [processing, setProcessing] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [dragOver, setDragOver] = useState(false)
  const [selected, setSelected] = useState(null)
  const [deleting, setDeleting] = useState(null)

  useEffect(() => { loadStatements() }, [])

  const loadStatements = async () => {
    const { data, error } = await supabase
      .from('statements')
      .select('*')
      .eq('user_id', user.id)
      .order('statement_date', { ascending: false })
    if (!error) setStatements(data || [])
  }

  const handleFile = async (file) => {
    if (!file || file.type !== 'application/pdf') {
      setError('Please upload a PDF file')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('File too large — max 10MB')
      return
    }

    setError(null)
    setUploading(true)

    try {
      // 1. Upload PDF to Supabase Storage
      const fileName = `${user.id}/${Date.now()}_${file.name.replace(/\s/g, '_')}`
      const { error: uploadError } = await supabase.storage
        .from('statements')
        .upload(fileName, file, { contentType: 'application/pdf' })
      if (uploadError) throw uploadError

      // 2. Read PDF as base64 for AI processing
      const base64 = await new Promise((resolve) => {
        const reader = new FileReader()
        reader.onload = (e) => resolve(e.target.result.split(',')[1])
        reader.readAsDataURL(file)
      })

      setUploading(false)
      setProcessing(true)

      // 3. Send to AI proxy to extract statement data
      const res = await fetch('/.netlify/functions/ai-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: `You are a bank statement parser. Extract data from this USAA bank statement and return ONLY valid JSON with this exact structure, no other text:
{
  "period_start": "YYYY-MM-DD",
  "period_end": "YYYY-MM-DD", 
  "beginning_balance": 0.00,
  "ending_balance": 0.00,
  "total_credits": 0.00,
  "total_debits": 0.00,
  "transactions": [
    {
      "date": "YYYY-MM-DD",
      "description": "merchant name",
      "amount": 0.00,
      "type": "debit or credit",
      "category": "one of: food, subscriptions, shopping, gas, bills, transfers, income, other"
    }
  ]
}
Categories guide: food=restaurants/groceries, subscriptions=streaming/apps/recurring, shopping=retail/amazon, gas=fuel/transport, bills=utilities/insurance/mortgage/loan payments, transfers=zelle/venmo/cashapp/bank transfers, income=payroll/deposits/VA benefits, other=everything else`,
          messages: [{
            role: 'user',
            content: [{
              type: 'document',
              source: { type: 'base64', media_type: 'application/pdf', data: base64 }
            }, {
              type: 'text',
              text: 'Extract all transaction data from this bank statement and return as JSON only.'
            }]
          }]
        })
      })

      const aiData = await res.json()
      const rawText = aiData.content?.find(b => b.type === 'text')?.text || ''

      // Parse JSON from AI response
      let parsed
      try {
        const jsonMatch = rawText.match(/\{[\s\S]*\}/)
        parsed = JSON.parse(jsonMatch?.[0] || rawText)
      } catch {
        throw new Error('Could not parse statement data. Please try again.')
      }

      // 4. Save statement record to database
      const { data: stmt, error: stmtError } = await supabase
        .from('statements')
        .insert({
          user_id: user.id,
          file_name: file.name,
          file_path: fileName,
          period_start: parsed.period_start,
          period_end: parsed.period_end,
          statement_date: parsed.period_end,
          beginning_balance: parsed.beginning_balance,
          ending_balance: parsed.ending_balance,
          total_credits: parsed.total_credits,
          total_debits: parsed.total_debits,
          transaction_count: parsed.transactions?.length || 0
        })
        .select()
        .single()
      if (stmtError) throw stmtError

      // 5. Save all transactions
      if (parsed.transactions?.length > 0) {
        const txRows = parsed.transactions.map(tx => ({
          user_id: user.id,
          statement_id: stmt.id,
          date: tx.date,
          description: tx.description,
          amount: Math.abs(tx.amount),
          type: tx.type,
          category: tx.category || 'other'
        }))
        const { error: txError } = await supabase.from('transactions').insert(txRows)
        if (txError) throw txError
      }

      setSuccess(`✅ "${file.name}" uploaded — ${parsed.transactions?.length || 0} transactions saved!`)
      loadStatements()

    } catch (err) {
      setError(`Upload failed: ${err.message}`)
    }

    setUploading(false)
    setProcessing(false)
  }

  const deleteStatement = async (stmt) => {
    setDeleting(stmt.id)
    try {
      // Delete transactions
      await supabase.from('transactions').delete().eq('statement_id', stmt.id)
      // Delete storage file
      await supabase.storage.from('statements').remove([stmt.file_path])
      // Delete record
      await supabase.from('statements').delete().eq('id', stmt.id)
      setStatements(prev => prev.filter(s => s.id !== stmt.id))
      if (selected?.id === stmt.id) setSelected(null)
    } catch (err) {
      setError(`Delete failed: ${err.message}`)
    }
    setDeleting(null)
  }

  const downloadStatement = async (stmt) => {
    const { data } = await supabase.storage.from('statements').download(stmt.file_path)
    if (data) {
      const url = URL.createObjectURL(data)
      const a = document.createElement('a')
      a.href = url
      a.download = stmt.file_name
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  const totalSaved = statements.reduce((s, st) => s + (st.total_credits || 0), 0)
  const totalSpent = statements.reduce((s, st) => s + (st.total_debits || 0), 0)
  const totalTx = statements.reduce((s, st) => s + (st.transaction_count || 0), 0)

  return (
    <div>
      <div style={{ fontFamily: 'Georgia, serif', fontSize: 28, fontWeight: 700, marginBottom: 4 }}>📁 Statement Library</div>
      <div style={{ fontSize: 13, color: C.muted, marginBottom: 24 }}>Upload bank statements — transactions are extracted and stored permanently</div>

      {/* Summary stats */}
      {statements.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Statements', value: statements.length, color: C.blue },
            { label: 'Total Transactions', value: totalTx.toLocaleString(), color: C.green },
            { label: 'Total Credited', value: `$${totalSaved.toLocaleString(undefined,{maximumFractionDigits:0})}`, color: C.green },
            { label: 'Total Debited', value: `$${totalSpent.toLocaleString(undefined,{maximumFractionDigits:0})}`, color: C.red },
          ].map(s => (
            <div key={s.label} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ fontSize: 10, color: C.muted, letterSpacing: 2, textTransform: 'uppercase', marginBottom: 5 }}>{s.label}</div>
              <div style={{ fontSize: 20, fontWeight: 900, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Upload area */}
      <div
        onDragOver={e => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={e => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]) }}
        onClick={() => !uploading && !processing && document.getElementById('stmt-upload').click()}
        style={{
          background: dragOver ? 'rgba(0,212,170,0.08)' : C.surface,
          border: `2px dashed ${dragOver ? C.green : C.border}`,
          borderRadius: 16, padding: '36px 24px', textAlign: 'center',
          cursor: uploading || processing ? 'wait' : 'pointer',
          marginBottom: 18, transition: 'all 0.2s'
        }}>
        <input id="stmt-upload" type="file" accept=".pdf" style={{ display: 'none' }}
          onChange={e => handleFile(e.target.files[0])} />

        {uploading ? (
          <>
            <div style={{ fontSize: 32, marginBottom: 10 }}>📤</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.green }}>Uploading PDF...</div>
            <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>Saving to secure storage</div>
          </>
        ) : processing ? (
          <>
            <div style={{ fontSize: 32, marginBottom: 10 }}>🤖</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.blue }}>AI is reading your statement...</div>
            <div style={{ fontSize: 12, color: C.muted, marginTop: 4 }}>Extracting and categorizing all transactions</div>
            <div style={{ marginTop: 12, display: 'flex', justifyContent: 'center', gap: 6 }}>
              {[0,1,2].map(i => (
                <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: C.blue, animation: 'bounce 1.2s ease-in-out infinite', animationDelay: `${i*0.2}s` }} />
              ))}
            </div>
          </>
        ) : (
          <>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📄</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.text, marginBottom: 6 }}>Drop your bank statement here</div>
            <div style={{ fontSize: 12, color: C.muted }}>or click to browse · PDF only · Max 10MB</div>
            <div style={{ fontSize: 11, color: C.muted, marginTop: 8 }}>AI will automatically extract and categorize all transactions</div>
          </>
        )}
      </div>

      {/* Messages */}
      {error && <div style={{ background: 'rgba(255,87,87,0.1)', border: '1px solid rgba(255,87,87,0.3)', borderRadius: 10, padding: '10px 14px', marginBottom: 14, fontSize: 13, color: C.red }}>{error}</div>}
      {success && <div style={{ background: 'rgba(0,212,170,0.1)', border: '1px solid rgba(0,212,170,0.3)', borderRadius: 10, padding: '10px 14px', marginBottom: 14, fontSize: 13, color: C.green }}>{success}</div>}

      {/* Statement list */}
      {statements.length === 0 ? (
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: '48px 24px', textAlign: 'center' }}>
          <div style={{ fontSize: 36, marginBottom: 12 }}>🗂️</div>
          <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 6 }}>No statements yet</div>
          <div style={{ fontSize: 13, color: C.muted }}>Upload your first USAA statement above to get started</div>
        </div>
      ) : (
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 22 }}>
          <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>📋 Uploaded Statements ({statements.length})</div>
          {statements.map(stmt => (
            <div key={stmt.id}
              onClick={() => setSelected(selected?.id === stmt.id ? null : stmt)}
              style={{
                display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px',
                borderRadius: 10, marginBottom: 8, cursor: 'pointer',
                background: selected?.id === stmt.id ? 'rgba(0,212,170,0.08)' : C.surface2,
                border: `1px solid ${selected?.id === stmt.id ? C.green : C.border}`,
                transition: 'all 0.15s'
              }}>
              <div style={{ fontSize: 24, flexShrink: 0 }}>🏦</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{stmt.file_name}</div>
                <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>
                  {stmt.period_start} → {stmt.period_end} · {stmt.transaction_count} transactions
                </div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{ fontSize: 12, color: C.green, fontWeight: 700 }}>+${(stmt.total_credits||0).toLocaleString(undefined,{maximumFractionDigits:0})}</div>
                <div style={{ fontSize: 12, color: C.red }}>-${(stmt.total_debits||0).toLocaleString(undefined,{maximumFractionDigits:0})}</div>
              </div>
              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }} onClick={e => e.stopPropagation()}>
                <button onClick={() => downloadStatement(stmt)}
                  style={{ background: 'rgba(74,158,255,0.15)', border: '1px solid rgba(74,158,255,0.3)', color: C.blue, borderRadius: 6, padding: '5px 10px', fontSize: 11, cursor: 'pointer', fontWeight: 600 }}>
                  ⬇️ Download
                </button>
                <button onClick={() => deleteStatement(stmt)} disabled={deleting === stmt.id}
                  style={{ background: 'rgba(255,87,87,0.1)', border: '1px solid rgba(255,87,87,0.3)', color: C.red, borderRadius: 6, padding: '5px 10px', fontSize: 11, cursor: 'pointer', fontWeight: 600 }}>
                  {deleting === stmt.id ? '...' : '🗑️'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <style>{`@keyframes bounce{0%,80%,100%{opacity:.3;transform:scale(.8)}40%{opacity:1;transform:scale(1)}}`}</style>
    </div>
  )
}
